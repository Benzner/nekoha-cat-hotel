import { createContext, useContext, useState, useEffect } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';

const ReservationContext = createContext();

export function ReservationProvider({ children }) {
    const [data, setData] = useLocalStorage('nekohaCatHotelData', {
        reservations: [],
        history: []
    });

    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        // Simulate data loading
        const timer = setTimeout(() => {
            setIsLoading(false);
        }, 1000);
        return () => clearTimeout(timer);
    }, []);

    const saveReservation = (reservation) => {
        setData(prevData => {
            const newData = { ...prevData };

            if (reservation.id) {
                // Update existing
                const index = newData.reservations.findIndex(r => r.id === reservation.id);
                if (index !== -1) {
                    const oldReservation = { ...newData.reservations[index] };
                    newData.reservations[index] = { ...reservation, modifiedAt: new Date().toISOString() };

                    newData.history.unshift({
                        action: 'updated',
                        reservationId: reservation.id,
                        timestamp: new Date().toISOString(),
                        details: { before: oldReservation, after: reservation }
                    });
                }
            } else {
                // Create new
                const newReservation = {
                    ...reservation,
                    id: Date.now().toString(),
                    createdAt: new Date().toISOString(),
                    modifiedAt: new Date().toISOString(),
                    status: 'active'
                };
                newData.reservations.push(newReservation);

                newData.history.unshift({
                    action: 'created',
                    reservationId: newReservation.id,
                    timestamp: new Date().toISOString(),
                    details: newReservation
                });
            }

            return newData;
        });
    };

    const deleteReservation = (id) => {
        setData(prevData => {
            const newData = { ...prevData };
            const index = newData.reservations.findIndex(r => r.id === id);

            if (index !== -1) {
                const reservation = { ...newData.reservations[index] };
                newData.reservations.splice(index, 1);

                newData.history.unshift({
                    action: 'deleted',
                    reservationId: id,
                    timestamp: new Date().toISOString(),
                    details: reservation
                });
            }

            return newData;
        });
    };

    return (
        <ReservationContext.Provider value={{
            reservations: data.reservations,
            history: data.history,
            isLoading,
            saveReservation,
            deleteReservation
        }}>
            {children}
        </ReservationContext.Provider>
    );
}

export function useReservations() {
    const context = useContext(ReservationContext);
    if (!context) {
        throw new Error('useReservations must be used within a ReservationProvider');
    }
    return context;
}
