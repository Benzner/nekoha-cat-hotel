import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import './LoginScreen.css';

export default function LoginScreen() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const { login } = useAuth();

    const handleSubmit = (e) => {
        e.preventDefault();
        const result = login(username, password);

        if (!result.success) {
            setError(result.error);
            setTimeout(() => setError(''), 3000);
        }
    };

    return (
        <div className="login-screen">
            <div className="login-card">
                <div className="login-header">
                    <img src="/logo.png" alt="Nekoha Cat Hotel Logo" className="login-logo-img" />
                    <h1 className="login-title">NekohaCatHotel</h1>
                    <p className="login-subtitle">Room Reservation Management</p>
                </div>

                {error &&
                    <div className={`error-message ${error ? 'show' : ''}`}>
                        {error}
                    </div>
                }

                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label className="form-label" htmlFor="username">Username</label>
                        <input
                            type="text"
                            id="username"
                            className="form-input"
                            placeholder="Enter username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            autoComplete="username"
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label className="form-label" htmlFor="password">Password</label>
                        <input
                            type="password"
                            id="password"
                            className="form-input"
                            placeholder="Enter password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            autoComplete="current-password"
                            required
                        />
                    </div>

                    <button type="submit" className="btn btn-primary" style={{ width: '100%' }}>
                        Login
                    </button>
                </form>
            </div>
        </div>
    );
}
