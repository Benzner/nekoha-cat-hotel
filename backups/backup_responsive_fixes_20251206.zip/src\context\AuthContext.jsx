import { createContext, useContext } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';

const AuthContext = createContext();

export function AuthProvider({ children }) {
    const [session, setSession] = useLocalStorage('nekohaCatHotelSession', null);

    // Derive authentication state directly from session
    const isAuthenticated = session !== null && session !== undefined;

    const login = (username, password) => {
        if (username === 'NekohaCatHotel' && password === 'NekohaCatHotel') {
            setSession('true');
            return { success: true };
        }
        return { success: false, error: '❌ Invalid username or password. Please try again.' };
    };

    const logout = () => {
        setSession(null);
    };

    return (
        <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
